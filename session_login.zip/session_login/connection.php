<?php

$connection = mysqli_connect('localhost', 'root', 'Nishant@12345', 'login');

if (!$connection) {
     die(' Please Check Your Connection' . mysqli_error($connection));
}
?>