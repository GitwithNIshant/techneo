<?php
 $hostname = "localhost:8080/techneo";
?>