<!--                                     navbar                                                        -->
<nav class="navbar navbar-expand-lg text-white navbar-light hover-zoom" style="background-color: #415ABE;">
     <div class="container-fluid">
          <a class="navbar-brand hover-zoom">Publication</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
               data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
               aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse text-white hover-zoom" id="navbarSupportedContent">
               <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0 text-white hover-zoom">
                    <li class="nav-item text-white hover-zoom">
                         <a class="nav-link active text-white hover-zoom" aria-current="page"
                              href="/techneo/University/index.php"> University </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page" href="/techneo/College/index.php">
                              College </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page" href="/techneo/Faculty/index.php">
                              Faculty </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page" href="/techneo/Course/index.php">
                              Course </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page" href="/techneo/Book/index.php">
                              Book </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page"
                              href="/techneo/purchaseorder/index.php">
                              Purchase Order </a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link active text-white" aria-current="page"
                              href="/techneo/deliverychallen/index.php">
                              Delivery Challan </a>
                    </li> -->
                    <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                </li> -->
                    <!-- <li class="nav-item">
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                </li> -->
               </ul>
          </div>
     </div>
</nav>