<?php

$connection = mysqli_connect("localhost", "root", "Nishant@12345");
$db         = mysqli_select_db($connection, 'dbtechneo');

if (isset($_POST['insertdata'])) {
     //$Uid = $_POST['Uid'];
     $Pdate      = date('Y-m-d', strtotime($_POST['Pdate']));
     $Pstatus = $_POST['Pstatus'];
     $collegeId = $_POST['collegeId'];
     $bookId1 = $_POST['bookId1'];
     // $facultyID = $_POST['facultyID'];
     // $quentity = $_POST['quentity'];

     // $query = "INSERT INTO tblpurchaseorder (Pdate,Pstatus,collegeId) VALUES ('$Pdate','$Pstatus','$collegeId')";
     // // echo $query;
     // $query_run = mysqli_query($connection, $query);

     $query = "INSERT INTO tblitem (bookId) VALUES ('$bookId1')";
     echo $query;
     // $query_run = mysqli_query($connection, $query);

     // if ($query_run) {
     //      echo '<script> alert("Data Saved"); </script>';
     //      header('Location: index.php');
     // } else {
     //      echo '<script> alert("Data Not Saved"); </script>';
     // }
}

?>