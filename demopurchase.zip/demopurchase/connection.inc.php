<?php

$conn = mysqli_connect('localhost','root','Nishant@12345','dbtechneo');
