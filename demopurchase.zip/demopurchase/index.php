<?php
include 'connection.inc.php';
$country        = "SELECT * FROM tblUniversity";
$university_qry = mysqli_query($conn, $country);
$faculty        = "SELECT * FROM tblFaculty";
$faculty_qry    = mysqli_query($conn, $faculty);
$book           = "SELECT * FROM tblBook;";
$book_qry       = mysqli_query($conn, $book);


include("common/header.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Demo Purchase</title>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
     <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<style>
     .footer {
          flex-shrink: 0;
     }
</style>

<body>

     <div class="card">
          <div class="card-body">
               <form action="insert.php" method="POST">
                    <table id="datatableid_index" class="table table-hover table-bordered table-light">

                         <tbody>

                              <tr> <br>
                                   <td>
                                        <label class="container" for="pno">P.O.No: <b>1<b></label>
                                        <!-- <label type="text" id="pno" name="pno"><br><br> -->
                                   </td>
                                   <td>
                                        <section class="container">
                                             <label for="">Date</label>
                                             <input type="date" id="Pdate" name="Pdate" class="form-control"
                                                   />
                                        </section>
                                        <!-- <input type="text" id="Pdate" disabled /> -->

                                   </td>
                          




                                   <td>
                                        <div class="container">
                                        <select class="form-select" id="university" name="university">
                                             <option selected disabled>Select university</option>
                                             <?php while ($row = mysqli_fetch_assoc($university_qry)): ?>
                                                  <option value="<?php echo $row['universityID']; ?>"> <?php echo $row['universityName']; ?> </option>
                                                  <?php endwhile; ?>
                                             </select>
                                             </div>
                                   </td>
                                   <td>
                                        <select class="form-select" id="collegeId" name='collegeId'>
                                             <option selected disabled>Select college</option>
                                        </select>

                                   </td><br>
                                   <td>
                                   <div class="container">
                                        <label><b>Status</b></label>
                                        <select name="Pstatus" id="Pstatus">
                                             <option selected disabled>Select Status</option>
                                             <option value="compete">Complete</option>
                                             <option value="Semi Complete">Semi Complete</option>
                                             <!-- <option value="Third Year">Third Year</option>
                                <option value="Fourth Year">Fourth Year</option>
                                <option value="Fifth Year">Fifth Year</option> -->
                                        </select>
                                   </div>
                                             </td>
                                             <td>
                                   <div class="modal-footer">
                                        <button type="submit" name="insertdata" class="btn btn-primary">Save
                                             Data</button>
                                   </div>
                                   </td>



                              </tr>

                         </tbody>
                    </table>
               </form>
          </div>
     </div>


      <!-- =========================================================================================================== -->

    <div class="container">
        <div class="jumbotron">
            <div class="card">
                <ul>
                    <h2> Publication </h2>
                </ul>
            </div>
            <!-- <div class="card">
                <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#studentaddmodal">
                        ADD FACULTY
                    </button>
                </div>
            </div> -->

            <div class="card">
                <div class="card-body">

                    <?php
                    // $connection = mysqli_connect("localhost", "root", "Nishant@12345");
                    // $db         = mysqli_select_db($connection, 'dbtechneo');
                    
                    // $query     = "SELECT * FROM tblBook;";
                    // $query_run = mysqli_query($connection, $query);
                    
                    ?>
                    <table id="datatableid" class="table table-hover table-bordered table-light">
                        <thead>
                            <tr>
                                <th scope="col"> Sr.No </th>
                                <th scope="col"> Book Name </th>
                                <th scope="col"> Faculty Name </th>
                                <th scope="col"> Quantity </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $str = 1;
                            for ($str = 1; $str <= 150; $str++) {
                                ?>



                                <tr data-id='<?php echo $row['id'] ?>'>
                                    <td> <?php echo $str; ?> </td>
                                    <?php
                                    foreach ($book_qry as $key => $get) {
                                        ?> <td>
                                            <select class="form-select" id='bookId<?php echo $str?>' name="bookId">
                                                <option selected disabled>Select book</option>
                                                <?php while ($row = mysqli_fetch_assoc($book_qry)): ?>
                                                    <option value="<?php echo $row['bookId']; ?>"> <?php echo $row['bookName']; ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </td>
                                        <?php
                                    }
                                    foreach ($faculty_qry as $key => $get) {
                                        ?>

                                        <td>
                                            
                                                <select class="form-select" id="facultyID" name="facultyID">
                                                    <option selected disabled>Select faculty</option>
                                                    <?php while ($row = mysqli_fetch_assoc($faculty_qry)): ?>
                                                        <option value="<?php echo $row['facultyID']; ?>"> <?php echo $row['facultyName']; ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                        </td>
                                    <?php } ?>
                                    <td>
                                        <div class="form-group">
                                            <input type="text" name="quentity" id="quentity" value="1" class="form-control">
                                        </div>
                                    </td>
                                </tr>
                                <?php
                                //$str++;
                            }
                            ?>

                        </tbody>
                    </table>
                </div>

                <!-- <div class="w-100 d-flex pposition-relative justify-content-center">
                    <button class="btn btn-flat btn-primary" id="add_member" type="button" onclick="addItem();">Add New
                        Data</button>
                </div> -->
                <!-- <td><input type="button" value="Add" id="nameselbtn" onclick="javascript:addrow();" /></td> -->
                <div class="w-100 d-flex pposition-relative justify-content-center">
                <a class="btn btn-flat btn-primary" id="insertRow">Add new data</a>
                </div>
            </div>
        </div>
    </div>




     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">


     <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap4.min.js"></script>
     <script
          src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
     <script type="text/javascript" src="bootstrap-datepicker.de.js" charset="UTF-8"></script>




     <script>
          // University college
          $('#university').on('change', function () {
               var universityId = this.value;
               // console.log(universityId);
               $.ajax({
                    url: 'ajax/college.php',
                    type: "POST",
                    data: {
                         university_data: universityId
                    },
                    success: function (result) {
                         $('#collegeId').html(result);
                         console.log(result);
                    }
               })
          });

     </script>

     <script> document.getElementById("Pdate").value = new Date().toLocaleDateString(); </script>

     <!-- 
     <script>
         // console.log(universityId);
         $.ajax({
              url: 'ajax/college.php',
         type: "POST",
         data: {
              university_data: universityId
                },
         success: function (result) {
              $('#college').html(result);
         console.log(result);
                }
            })
        });

     </script> -->


     <script type="text/javascript">
          $('.input-group.date').datepicker({
               todayBtn: "linked",
               language: "it",
               autoclose: true,
               todayHighlight: true,
               format: 'dd/mm/yyyy',
          });
     </script>

     
    <script>
        $(document).ready(function () {
            var i = 1;
            
            
            $('#insertRow').click(function () {
                

                $('#datatableid').append('<tr id="row' + i + '"><td>' + (i + 150) +'</td><?php
                                    foreach ($book_qry as $key => $get) {
                                        ?> <td>\
                                           <select class="form-select" id="book" name="book">\
                                                <option selected disabled>Select book</option>\
                                                <?php while ($row = mysqli_fetch_assoc($book_qry)): ?>
                                                    <option value="<?php echo $row['bookId']; ?>"> <?php echo $row['bookName']; ?>\
                                                    </option>\
                                                <?php endwhile; ?>
                                            </select>\
                                        </td>\
                                        <?php } ?>
                                        <?php
                                    
                                    foreach ($faculty_qry as $key => $get) {
                                        ?>
                                        <td>\
                                                <select class="form-select" id="faculty" name="faculty">\
                                                    <option selected disabled>Select faculty</option>\
                                                    <?php while ($row = mysqli_fetch_assoc($faculty_qry)): ?>
                                                        <option value="<?php echo $row['facultyID']; ?>"> <?php echo $row['facultyName']; ?>
                                                        </option>\
                                                    <?php endwhile; ?>
                                                </select>\
                                        </td>\
                                    <?php } ?>
                                    <td>\
                                        <div class="form-group">\
                                            <input type="text" name="quentity" id="quentity" value="1" class="form-control">\
                                        </div>\
                                    </td>\
                                </tr>\
                                <?php
                                // $str++;
                            
                            ?>  ');
                i++;
            }); 
            $(document).on('click', '.btn_remove', function () {
                var button_id = $(this).attr("id");
                // alert(button_id);
                $('#row' + button_id + '').remove();
            });
            

        }); 
    </script>
     <!-- <script>
          document.getElementById('Pdate').valueAsDate = new Date();
     </script> -->


     <?php


     include 'common/footer.php' ?>

</body>

</html>